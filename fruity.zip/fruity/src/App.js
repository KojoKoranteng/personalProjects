import './App.css';
import MidSection from './components/pages/mid';
import NavbarC from './components/pages/nav';
import { Routes, Route } from 'react-router-dom'
import Register from './components/register/register';
import TableList from './components/list/list';
import Update from './components/update/update';

function App() {
  return (

    <>
      <NavbarC />
      <Routes>
        <Route path='/' exact element={<MidSection/>} />
        <Route path='/register' element={<Register />} />
        <Route path='/list' element={<TableList />} />
        <Route path='/update' element={<Update />} />
      </Routes>
    </>

  );
}

export default App;
