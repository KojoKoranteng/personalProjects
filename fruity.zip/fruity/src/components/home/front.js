import React from "react";
import MidSection from "../pages/mid";
import NavbarC from "../pages/nav";


function Front() {

    <div>
        <NavbarC />
        <MidSection />
    </div >

}

export default Front;