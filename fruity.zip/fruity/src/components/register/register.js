import React, { useState } from 'react';
import { Button, Form, Container } from 'semantic-ui-react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import{useNavigate} from 'react-router-dom'

// const options = [
//     { key: 'm', text: 'Male', value: 'male' },
//     { key: 'f', text: 'Female', value: 'female' },
// ]
// const locs = [
//     { key: 'md', text: 'Madina', value: 'madina' },
//     { key: 'ac', text: 'Accra', value: 'accra' },
//     { key: 'tm', text: 'Tema', value: 'tema' }
// ]

function Register() {
    let navigate=useNavigate()

    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [phone, setPhoneNumber] = useState('')
    // const [gender, setGender] = useState('')
    // const [loc, setLocation] = useState('')


    console.log(firstName)
    console.log(lastName)

    const handleInput = () => {
        axios.post('https://62bc59a76b1401736cf889ba.mockapi.io/fruveg', {
            firstName,
            lastName,
            email,
            phone,
        }).then(()=>{
            navigate('/list')
        })
    }
    return (
        <Container className='Con'>
            <h1>Registration Form</h1>
            <Form>
                <Form.Field>
                    <label>First Name</label>
                    <input name='fname' onChange={(e) => setFirstName(e.target.value)}
                        placeholder='First Name' />
                </Form.Field>
                <Form.Field>
                    <label>Last Name</label>
                    <input name='lname' onChange={(e) => setLastName(e.target.value)}
                        placeholder='Last Name...' />
                </Form.Field>
                <Form.Field>
                    <label>Email</label>
                    <input name='email' onChange={(e) => setEmail(e.target.value)}
                        placeholder='Email...' />
                </Form.Field>
                <Form.Field>
                    <label>Phone Number</label>
                    <input name='phone' onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder='Phone...' />
                </Form.Field>
                <Link to='/list'/>
                <Button onClick={handleInput} type='submit'>Submit</Button>
            </Form>

        </Container>
    );
}

export default Register;