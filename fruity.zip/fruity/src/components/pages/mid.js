import React from "react";
//import { Container } from 'semantic-ui-react'


function MidSection() {


    return (
        <div className="Con1">
            <div className="Midpadding">
                <img src="./midpic.jpg" alt=" " width={660}></img>
                <img src="./midpicc.jpg" alt=" " width={660}></img>
            </div>
            <div class="ui teal segment container">
                <h3>Fruits contain many nutrients for the body, hair and skin
                    ,and contain antioxidants that protect against many diseases such as cancer.</h3>
            </div>
            <div te class="ui center aligned segment container">
                <h5>Contact us for your fresh Fruits and Vegetables.</h5>
            </div>

            <div className="Seg">
                <div class="column"><a href="/register"><h3>Register with us</h3></a></div>
            </div>

        </div>

    )
}

export default MidSection;