import React, { Component } from 'react'
import { Input, Menu } from 'semantic-ui-react'

class NavbarC extends Component {
  state = { activeItem: 'home' }

  handleItemClick = (e, { name }) => this.setState({ activeItem: name })

  render() {
    const { activeItem } = this.state

    return (
      <Menu>
        <Menu.Item
          name='Home'
          active={activeItem === 'home'}
          onClick={this.handleItemClick}
          href='/'
        />
        <Menu.Item
          name='Register'
          active={activeItem === 'register'}
          onClick={this.handleItemClick}
          href='/register'
        />
        <Menu.Item
          name='Client List'
          active={activeItem === 'list'}
          onClick={this.handleItemClick}
          href='/list'
        />
        <Menu.Menu position='right'>
          <Menu.Item>
            <Input icon='search' placeholder='Search...' />
          </Menu.Item>
          <Menu.Item
            name='Contact Us'
            active={activeItem === 'contact'}
            onClick={this.handleItemClick}
          />
        </Menu.Menu>
      </Menu>
    )
  }
}

export default NavbarC;




<div class="ui secondary menu">
  <a class="active item">Home</a>
  <a class="item">Messages</a>
  <a class="item">Friends</a>
  <div class="right menu">
    <div class="item">
      <div class="ui icon input">
        <input type="text" placeholder="Search..."/>
        <i aria-hidden="true" class="search icon">
          </i>
      </div>
    </div>
    <a class="item">Logout</a></div></div>