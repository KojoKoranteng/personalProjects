import React, { useState,useEffect } from 'react';
import { Button, Form } from 'semantic-ui-react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import{useNavigate} from 'react-router-dom'
// const options = [
//     { key: 'm', text: 'Male', value: 'male' },
//     { key: 'f', text: 'Female', value: 'female' },
// ]
// const locs = [
//     { key: 'md', text: 'Madina', value: 'madina' },
//     { key: 'ac', text: 'Accra', value: 'accra' },
//     { key: 'tm', text: 'Tema', value: 'tema' }
// ]

function Update() {
    let navigate=useNavigate()

    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [phone, setPhoneNumber] = useState('')
    const [ID, setID]= useState(null)

    const handleInput = () => {
        axios.put('https://62bc59a76b1401736cf889ba.mockapi.io/fruveg/${ID}', {
            firstName,
            lastName,
            email,
            phone,
        }).then(()=>{
            navigate('/list')
        })
    }

    useEffect(()=>{
        setFirstName(localStorage.getItem('firstName'));
        setLastName(localStorage.getItem('lastName'));
        setEmail(localStorage.getItem('email'));
        setPhoneNumber(localStorage.getItem('phone'));
        setID(localStorage.getItem('ID'))
    },[])


    return (
        <div className='Container'>
            <Form>
                <Form.Field>
                    <label>First Name</label>
                    <input name='fname' value={firstName} onChange={(e) => setFirstName(e.target.value)}
                        placeholder='First Name'/>
                </Form.Field>
                <Form.Field>
                    <label>Last Name</label>
                    <input name='lname' value={lastName} onChange={(e) => setLastName(e.target.value)}
                        placeholder='Last Name...'/>
                </Form.Field>
                <Form.Field>
                    <label>Email</label>
                    <input name='email' value={email} onChange={(e) => setEmail(e.target.value)}
                        placeholder='Email...'/>
                </Form.Field>
                <Form.Field>
                    <label>Phone Number</label>
                    <input name='phone' value={phone} onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder='Phone...'/>
                </Form.Field>
                <Link to='/list'/>
                <Button onClick={handleInput} type='submit' >Update</Button>
            </Form>

        </div>
    );
}

export default Update;